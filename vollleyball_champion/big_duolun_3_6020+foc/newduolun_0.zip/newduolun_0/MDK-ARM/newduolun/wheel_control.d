newduolun/wheel_control.o: ..\Control\wheel_control.c \
  ..\Control\wheel_control.h ..\Motor\vesc.h \
  ..\Drivers\CMSIS\Device\ST\STM32G4xx\Include\stm32g4xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32G4xx\Include\stm32g473xx.h \
  ..\Drivers\CMSIS\Include\core_cm4.h \
  F:\Keil\ARM\ARMCLANG\Bin\..\include\stdint.h \
  ..\Drivers\CMSIS\Include\cmsis_version.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  F:\Keil\ARM\ARMCLANG\Bin\..\include\arm_compat.h \
  F:\Keil\ARM\ARMCLANG\Bin\..\include\arm_acle.h \
  ..\Drivers\CMSIS\Include\mpu_armv7.h \
  ..\Drivers\CMSIS\Device\ST\STM32G4xx\Include\system_stm32g4xx.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal.h \
  ..\Core\Inc\stm32g4xx_hal_conf.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_rcc.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_def.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  F:\Keil\ARM\ARMCLANG\Bin\..\include\stddef.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_rcc_ex.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_gpio.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_gpio_ex.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_dma.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_dma_ex.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_cortex.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_exti.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_fdcan.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_flash.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_flash_ex.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_flash_ramfunc.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_pwr.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_pwr_ex.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_uart.h \
  ..\Drivers\STM32G4xx_HAL_Driver\Inc\stm32g4xx_hal_uart_ex.h \
  ..\Motor\dji_6020_motor.h ..\Core\Inc\main.h \
  ..\Communication\can_database.h ..\Motor\rc_foc_motor.h ..\Bsp\delay.h
