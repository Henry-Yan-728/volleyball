#include "rc_foc_motor.h"
#include "main.h"
#include "pid.h"
#include "fdcan.h"
#include "basic.h"
#include "can_database.h"

float_to_u8 blazer_content_transform[Motor_Num];

CAN_Data_TypeDef CAN_Data[Motor_Num]=
{
	{0x00, (uint8_t*)(&blazer_content_transform[0].u8_data)},
	{0x01, (uint8_t*)(&blazer_content_transform[1].u8_data)},
	{0x02, (uint8_t*)(&blazer_content_transform[2].u8_data)},
	{0x03, (uint8_t*)(&blazer_content_transform[3].u8_data)},
	{0x04, (uint8_t*)(&blazer_content_transform[4].u8_data)},
	{0x05, (uint8_t*)(&blazer_content_transform[5].u8_data)},
	{0x06, (uint8_t*)(&blazer_content_transform[6].u8_data)},
	{0x07, (uint8_t*)(&blazer_content_transform[7].u8_data)},
};

uint32_t FloatToIntBit(float x)
{
	uint32_t *pInt;
	pInt = (uint32_t*)(&x);
	return *pInt;
}

float IntBitToFloat(uint32_t x)
{
	float * pFloat;
	pFloat = (float *)(&x);
	return *pFloat;
}

/**
   * @brief  CAN1��������ʼ������
   * @param  ��
   * @retval ��
   */
void CAN_Filter_Init(void)
{

	FDCAN_FilterTypeDef sFilterConfig;
	sFilterConfig.IdType = FDCAN_STANDARD_ID;
	sFilterConfig.FilterIndex = 0;
	sFilterConfig.FilterType = FDCAN_FILTER_RANGE;
	sFilterConfig.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;
	sFilterConfig.FilterID1 = 0x00000000;
	sFilterConfig.FilterID2 = 0X1FFFFFFF;
  HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig);
}

/**
   * @brief  CAN���ͱ���
   * @param  ID �ɽڵ�ID�Ͳ���ID���ɵĸ���ID
   * @retval ��
   */
void CAN_SendMessage(uint32_t ID)
{
	FDCAN_TxHeaderTypeDef CAN_TxHeaderStruct;
	uint8_t send_num = 0;
	uint32_t pTxMailbox = 0;
	
	CAN_TxHeaderStruct.Identifier			  = ID;
	CAN_TxHeaderStruct.IdType			  = FDCAN_EXTENDED_ID ;
	CAN_TxHeaderStruct.TxFrameType 			= FDCAN_DATA_FRAME;		/* ����֡ */
	CAN_TxHeaderStruct.DataLength 			= 0X04;					/* �������ݳ��� */
	CAN_TxHeaderStruct.ErrorStateIndicator 	= FDCAN_ESI_ACTIVE;		/* ���ô���״ָ̬ */
	CAN_TxHeaderStruct.BitRateSwitch 		= FDCAN_BRS_OFF;		/* �رտɱ䲨���� */
	CAN_TxHeaderStruct.FDFormat 				= FDCAN_CLASSIC_CAN;			/* FDCAN��ʽ */
	CAN_TxHeaderStruct.TxEventFifoControl 	= FDCAN_NO_TX_EVENTS;	/* ���ڷ����¼�FIFO����, �޷����¼�*/
	CAN_TxHeaderStruct.MessageMarker 		= 0;					/* ���ڸ��Ƶ�TX EVENT FIFO����ϢMaker��ʶ����Ϣ״̬����Χ0-0xFF */
	
	while(HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &CAN_TxHeaderStruct, CAN_Data[ID >> 8].data_ptr) != HAL_OK)
	{
		delay_us(25);
		/*��������*/
		if(++ send_num == 10)
			break;
	}
}

/**
   * @brief  �趨����ģʽ
   * @param  node_id   �����ڵ�ID 
			 mode      ģʽ 
			 0:����״̬ 	1:����ģʽ 2:�ٶ�ģʽ 3:λ��ģʽ 4:У׼�����д��� 
		     5:У׼������ƫ�� 6:�ָ�Ĭ������ 7:���浱ǰ���� 8:�������
   * @retval ��
   */
void set_blazer_mode(uint32_t node_id, float mode)
{
	uint32_t blazer_mode_id = node_id << 8 | CAN_SET_MODE;
	uint32_t mode_u32;
	
	mode_u32 = FloatToIntBit(mode);
	
	blazer_content_transform[node_id].u8_data[0] = mode_u32 >> 24;
	blazer_content_transform[node_id].u8_data[1] = mode_u32 >> 16;
	blazer_content_transform[node_id].u8_data[2] = mode_u32 >> 8;
	blazer_content_transform[node_id].u8_data[3] = mode_u32;
	
	CAN_SendMessage(blazer_mode_id);
}

/**
   * @brief  �趨���ת��
			 ת��Ϊ��еת��
   * @param  node_id �����ڵ�ID 
             speed   �趨�ٶ�(r/s)
   * @retval ��
   */
void set_blazer_speed(uint32_t node_id, float speed)
{
	uint32_t blazer_speed_id = node_id << 8 | CAN_SET_SPEED;
	uint32_t speed_u32;
	
	speed_u32 = FloatToIntBit(speed);
	
	blazer_content_transform[node_id].u8_data[0] = speed_u32 >> 24;
	blazer_content_transform[node_id].u8_data[1] = speed_u32 >> 16;
	blazer_content_transform[node_id].u8_data[2] = speed_u32 >> 8;
	blazer_content_transform[node_id].u8_data[3] = speed_u32;
	
	CAN_SendMessage(blazer_speed_id);
}

/**
   * @brief  �趨������ٶ�
   * @param  node_id   �����ڵ�ID 
             speed_acc �趨���ٶ�(r/(s*s))
   * @retval ��
   */
void set_blazer_speed_acc(uint32_t node_id, float speed_acc)
{
	uint32_t blazer_speed_acc_id = node_id << 8 | CAN_SET_ACC;
	uint32_t speed_acc_u32;
	
	speed_acc_u32 = FloatToIntBit(speed_acc);
	
	blazer_content_transform[node_id].u8_data[0] = speed_acc_u32 >> 24;
	blazer_content_transform[node_id].u8_data[1] = speed_acc_u32 >> 16;
	blazer_content_transform[node_id].u8_data[2] = speed_acc_u32 >> 8;
	blazer_content_transform[node_id].u8_data[3] = speed_acc_u32;
	
	CAN_SendMessage(blazer_speed_acc_id);
}

/**
   * @brief  �趨������ٶ�
   * @param  node_id   �����ڵ�ID 
             speed_dec �趨���ٶ�(r/(s*s))
   * @retval ��
   */
void set_blazer_speed_dec(uint32_t node_id, float speed_dec)
{
	uint32_t blazer_speed_dec_id = node_id << 8 | CAN_SET_DEC;
	uint32_t speed_dec_u32;
	
	speed_dec_u32 = FloatToIntBit(speed_dec);
	
	blazer_content_transform[node_id].u8_data[0] = speed_dec_u32 >> 24;
	blazer_content_transform[node_id].u8_data[1] = speed_dec_u32 >> 16;
	blazer_content_transform[node_id].u8_data[2] = speed_dec_u32 >> 8;
	blazer_content_transform[node_id].u8_data[3] = speed_dec_u32;
	
	CAN_SendMessage(blazer_speed_dec_id);
}


/**
   * @brief  �趨�ٶȻ�kp
   * @param  node_id �����ڵ�ID 
             kp 	 �ٶȻ�kp
   * @retval ��
   */
void set_blazer_speed_kp(uint32_t node_id, float speed_kp)
{
	uint32_t blazer_speed_kp_id = node_id << 8 | CAN_SET_SPEED_KP;
	uint32_t speed_kp_u32;
	
	speed_kp_u32 = FloatToIntBit(speed_kp);
	
	blazer_content_transform[node_id].u8_data[0] = speed_kp_u32 >> 24;
	blazer_content_transform[node_id].u8_data[1] = speed_kp_u32 >> 16;
	blazer_content_transform[node_id].u8_data[2] = speed_kp_u32 >> 8;
	blazer_content_transform[node_id].u8_data[3] = speed_kp_u32;
	
	CAN_SendMessage(blazer_speed_kp_id);
}

/**
   * @brief  �趨�ٶȻ�ki
   * @param  node_id �����ڵ�ID 
             kp 	 �ٶȻ�ki
   * @retval ��
   */
void set_blazer_speed_ki(uint32_t node_id, float speed_ki)
{
	uint32_t blazer_speed_ki_id = node_id << 8 | CAN_SET_SPEED_KI;
	uint32_t speed_ki_u32;
	
	speed_ki_u32 = FloatToIntBit(speed_ki);
	
	blazer_content_transform[node_id].u8_data[0] = speed_ki_u32 >> 24;
	blazer_content_transform[node_id].u8_data[1] = speed_ki_u32 >> 16;
	blazer_content_transform[node_id].u8_data[2] = speed_ki_u32 >> 8;
	blazer_content_transform[node_id].u8_data[3] = speed_ki_u32;
	
	CAN_SendMessage(blazer_speed_ki_id);
}
